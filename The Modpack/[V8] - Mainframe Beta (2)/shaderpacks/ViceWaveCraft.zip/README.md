# ViceWave — shader style GTA VI / Miami vice-wave

Shaderpack pour Minecraft 1.21.x + Iris (Fabric). Direction artistique inspirée de GTA VI :
couchers de soleil rose/orange/violet, nuits lavande, torches néon, eau qui reflète le ciel,
bloom sur les sources lumineuses et étalonnage "Vice" (ombres violettes, hautes lumières rose chaud).

## Activation
Le pack fonctionne en dossier (non zippé) : sélectionne simplement **ViceWave** dans
Options → Options graphiques → Packs de shaders. Après une modification de fichier,
ré-applique le pack (ou utilise le bouton de rechargement d'Iris) pour recompiler.

## Structure
- `shaders/settings.glsl` — toutes les options (visibles dans le menu réglages du pack)
- `shaders/common/palette.glsl` — LA palette : ciel, soleil, ambiance, torches néon. C'est ici qu'on règle l'ambiance.
- `shaders/program/` — le vrai code des programmes (partagé entre dimensions)
  - `solid.*` — terrain/entités/main (lightmap custom, ombres PCF, fog vers l'horizon)
  - `water.*` — eau : vagues procédurales + reflet du dégradé de ciel + glint soleil/lune
  - `skybasic.*` — ciel procédural (dégradé jour/crépuscule/nuit + étoiles)
  - `bloom.fsh` — bloom en 4 passes (extract + 2× blur H/V)
  - `final.fsh` — tonemap ACES + étalonnage Vice + vignette
- `shaders/world0|world-1|world1/` — stubs de 3 lignes par dimension (Overworld/Nether/End)

## Réglages clés (menu shader)
- **Intensité du couchant** — force du rose/orange au crépuscule
- **Lumière néon** — 0 = torches chaudes classiques, 1 = magenta total
- **Étalonnage Vice** — la teinte violette globale du rendu
- **Angle du soleil** — par défaut -30° pour des couchers de soleil de biais
