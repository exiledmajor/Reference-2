#include "/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;

varying vec2 texUV;
varying vec2 lightUV;
varying vec4 vColor;
varying vec3 feetPos;
varying vec3 worldNormal;
varying vec3 sunDirW;
varying float emissive;

#ifdef SHADOWS_ACTIVE
   uniform mat4 shadowModelView;
   uniform mat4 shadowProjection;
   uniform vec3 shadowLightPosition;

   varying vec4 shadowPos;
   varying float NdotL;
#endif

#ifdef TERRAIN
   attribute vec4 mc_Entity;
   attribute vec3 at_midBlock;

   #ifdef WAVING
      uniform mat4 gbufferModelView;
      uniform vec3 cameraPosition;
      uniform float frameTimeCounter;
   #endif
#endif

void main() {
   vec4 viewPos4 = gl_ModelViewMatrix * gl_Vertex;
   vec3 viewPos  = viewPos4.xyz;

   feetPos     = (gbufferModelViewInverse * viewPos4).xyz;
   worldNormal = normalize(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal));
   sunDirW     = normalize(mat3(gbufferModelViewInverse) * sunPosition);

   vColor  = gl_Color;
   texUV   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
   lightUV = clamp(((gl_TextureMatrix[1] * gl_MultiTexCoord1).st - 0.03125) * 1.06667, 0.0, 1.0);

   emissive = 0.0;
   float thinPlant = 0.0;

#ifdef TERRAIN
   float blockId = mc_Entity.x;
   if (blockId >= 10010.0 && blockId <= 10016.0) emissive = 1.0;
   if (blockId == 10001.0) thinPlant = 1.0;

   #ifdef WAVING
      float wave = 0.0;
      if (mc_Entity.x == 10001.0) wave = clamp(0.5 - at_midBlock.y / 24.0, 0.0, 1.0);
      if (mc_Entity.x == 10002.0) wave = 0.35;

      if (wave > 0.0) {
         vec3 wp = feetPos + cameraPosition;
         float t = frameTimeCounter * WAVING_SPEED;
         vec2 sway = vec2(
            sin(t * 1.7 + wp.x * 0.9 + wp.z * 0.6) + 0.5 * sin(t * 2.6 + wp.x * 1.9),
            sin(t * 1.4 + wp.z * 1.1 + wp.x * 0.5) + 0.5 * sin(t * 2.2 + wp.z * 1.7)
         );
         feetPos.xz += sway * 0.028 * wave;
         viewPos = (gbufferModelView * vec4(feetPos, 1.0)).xyz;
      }
   #endif
#endif

#ifdef FACE_SHADE
   // vanilla-style directional face shading: top lit, sides dimmer, bottom darkest
   vec3 n = worldNormal;
   float faceShade = min(1.0, n.x * n.x * 0.6
                            + n.y * n.y * 0.25 * (3.0 + n.y)
                            + n.z * n.z * 0.8);
   vColor.rgb *= mix(faceShade, 1.0, thinPlant);
#endif

#ifdef SHADOWS_ACTIVE
   float lightDot = dot(normalize(shadowLightPosition), normalize(gl_NormalMatrix * gl_Normal));
   NdotL = mix(max(lightDot, 0.0), 0.9, thinPlant);

   // normal offset against shadow acne
   vec3 offsetPos = feetPos + worldNormal * 0.08;
   shadowPos = shadowProjection * (shadowModelView * vec4(offsetPos, 1.0));
#endif

   gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
}
