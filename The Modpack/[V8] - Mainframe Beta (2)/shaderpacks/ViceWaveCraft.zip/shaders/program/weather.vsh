#include "/settings.glsl"

varying vec2 texUV;
varying vec2 lightUV;
varying vec4 vColor;

void main() {
   gl_Position = ftransform();
   texUV   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
   lightUV = clamp((gl_TextureMatrix[1] * gl_MultiTexCoord1).st, 0.0, 1.0);
   vColor  = gl_Color;
}
