#include "/settings.glsl"
#include "/common/palette.glsl"

uniform sampler2D gtexture;
uniform float rainStrength;
uniform float far;

varying vec2 texUV;
varying vec4 vColor;
varying vec3 feetPos;
varying vec3 sunDirW;

void main() {
   vec4 albedo = texture2D(gtexture, texUV) * vColor;

   vec3 ph = vw_phase(sunDirW.y);
   vec3 tint = ph.x * vec3(1.00, 0.96, 0.98)
             + ph.y * vec3(1.25, 0.55, 0.70)
             + ph.z * vec3(0.10, 0.09, 0.22) * NIGHT_BRIGHTNESS;
   albedo.rgb *= tint * 1.15;
   albedo.rgb *= 1.0 - 0.5 * rainStrength;

   float dist = length(feetPos);
   vec3 dir = feetPos / max(dist, 0.001);
   vec3 fogCol = vw_fogColor(dir, sunDirW, rainStrength);
   float fogAmt = 1.0 - exp(-pow(dist / far * 1.1 * FOG_DENSITY, 2.0));
   albedo.rgb = mix(albedo.rgb, fogCol, clamp(fogAmt, 0.0, 1.0));

   albedo.a *= 0.92;

/* DRAWBUFFERS:0 */
   gl_FragData[0] = albedo;
}
