#include "/settings.glsl"

uniform sampler2D gtexture;

varying vec2 texUV;
varying vec4 vColor;

void main() {
   vec4 albedo = texture2D(gtexture, texUV) * vColor;

   // unlit + boosted so it feeds the bloom pass (beacon beams, glowing eyes)
#ifdef BEACON
   albedo.rgb *= 1.8;
#else
   albedo.rgb *= 1.2;
#endif

/* DRAWBUFFERS:0 */
   gl_FragData[0] = albedo;
}
