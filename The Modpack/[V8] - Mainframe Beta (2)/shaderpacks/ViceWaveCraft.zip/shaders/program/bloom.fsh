// stubs define: PASS_EXTRACT (first pass only), DIR_H or DIR_V, STRIDE
#include "/settings.glsl"

uniform float viewWidth;
uniform float viewHeight;

#ifdef PASS_EXTRACT
   uniform sampler2D colortex0;
#else
   uniform sampler2D colortex1;
#endif

varying vec2 uv;

vec3 fetch(vec2 p) {
#ifdef PASS_EXTRACT
   // only genuinely HDR pixels bloom (emissives, sun, dusk sky near the sun)
   vec3 c = texture2D(colortex0, p).rgb;
   return c * smoothstep(1.0, 2.2, vw_luma(c));
#else
   return texture2D(colortex1, p).rgb;
#endif
}

void main() {
#ifndef BLOOM
   vec3 acc = vec3(0.0);
#else
   #ifdef DIR_H
      vec2 stepv = vec2(STRIDE / viewWidth, 0.0);
   #else
      vec2 stepv = vec2(0.0, STRIDE / viewHeight);
   #endif

   vec3 acc = fetch(uv) * 0.227;
   acc += (fetch(uv + stepv * 1.385) + fetch(uv - stepv * 1.385)) * 0.316;
   acc += (fetch(uv + stepv * 3.230) + fetch(uv - stepv * 3.230)) * 0.0703;
#endif

/* DRAWBUFFERS:1 */
   gl_FragData[0] = vec4(acc, 1.0);
}
