#include "/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;

attribute vec4 mc_Entity;

varying vec2 texUV;
varying vec2 lightUV;
varying vec4 vColor;
varying vec3 feetPos;
varying vec3 worldNormal;
varying vec3 sunDirW;
varying float isWater;

void main() {
   gl_Position = ftransform();

   vec4 viewPos4 = gl_ModelViewMatrix * gl_Vertex;

   feetPos     = (gbufferModelViewInverse * viewPos4).xyz;
   worldNormal = normalize(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal));
   sunDirW     = normalize(mat3(gbufferModelViewInverse) * sunPosition);

   vColor  = gl_Color;
   texUV   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
   lightUV = clamp(((gl_TextureMatrix[1] * gl_MultiTexCoord1).st - 0.03125) * 1.06667, 0.0, 1.0);

   isWater = float(mc_Entity.x == 10003.0);
}
