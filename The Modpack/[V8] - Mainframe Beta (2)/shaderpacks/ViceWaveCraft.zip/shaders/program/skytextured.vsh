#include "/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;

varying vec2 texUV;
varying vec4 vColor;
varying vec3 sunDirW;

void main() {
   gl_Position = ftransform();
   texUV   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
   vColor  = gl_Color;
   sunDirW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
}
