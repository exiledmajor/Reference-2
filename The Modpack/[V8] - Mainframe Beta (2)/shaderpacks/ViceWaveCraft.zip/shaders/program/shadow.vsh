#include "/settings.glsl"

varying vec2 texUV;
varying vec4 vColor;

void main() {
   vec4 pos = ftransform();
   pos.xy = vw_distortShadow(pos.xy);
   gl_Position = pos;

   texUV  = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
   vColor = gl_Color;
}
