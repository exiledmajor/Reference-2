#include "/settings.glsl"
#include "/common/palette.glsl"

uniform sampler2D gtexture;
uniform vec4 entityColor;
uniform float rainStrength;
uniform float far;
uniform int isEyeInWater;

#ifdef NETHER
   uniform vec3 fogColor;
#endif

varying vec2 texUV;
varying vec2 lightUV;
varying vec4 vColor;
varying vec3 feetPos;
varying vec3 worldNormal;
varying vec3 sunDirW;
varying float emissive;

#ifdef SHADOWS_ACTIVE
   uniform sampler2D shadowtex1;

   varying vec4 shadowPos;
   varying float NdotL;

   float shadowTap(vec2 uv, float z) {
      return step(z, texture2D(shadowtex1, uv).x);
   }

   float getShadow() {
      vec3 p = shadowPos.xyz;
      p.xy = vw_distortShadow(p.xy);
      p = p * 0.5 + 0.5;
      if (clamp(p.xy, 0.0, 1.0) != p.xy) return 1.0;

      float z = p.z - 0.0014;
      float r = (0.5 + SHADOW_SOFTNESS) / float(shadowMapResolution);
      float s = shadowTap(p.xy + vec2( r,  r), z)
              + shadowTap(p.xy + vec2(-r,  r), z)
              + shadowTap(p.xy + vec2( r, -r), z)
              + shadowTap(p.xy + vec2(-r, -r), z);
      s *= 0.25;

      float fade = smoothstep(0.75, 1.0, length(feetPos) / shadowDistance);
      return mix(s, 1.0, fade);
   }
#endif

void main() {
   vec4 albedo = texture2D(gtexture, texUV);

#ifdef TERRAIN
   float ao = vColor.a; // separateAo=true: vertex alpha carries AO
#else
   float ao = 1.0;
   albedo.a *= vColor.a;
#endif

   if (albedo.a < 0.102) discard;

   albedo.rgb *= vColor.rgb;
   albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);

   vec3 base = albedo.rgb;

   float skyL   = lightUV.t;
   float blockL = lightUV.s;

   vec3 light = vw_ambientColor(sunDirW.y, rainStrength) * (0.15 + 0.85 * skyL * skyL);
   light += vw_blocklightColor(blockL);
   light += vec3(0.030, 0.028, 0.045); // never fully black

   float sunVis = pow(skyL, 3.0);
#ifdef SHADOWS_ACTIVE
   light += vw_sunlightColor(sunDirW.y, rainStrength) * (NdotL * sunVis * getShadow());
#else
   light += vw_sunlightColor(sunDirW.y, rainStrength)
          * (0.75 * sunVis) * (0.6 + 0.4 * max(worldNormal.y, 0.0));
#endif

   albedo.rgb = base * light * ao;
   // emissive blocks stay at their natural texture brightness, no strong boost
   albedo.rgb = mix(albedo.rgb, base * EMISSIVE_BOOST, emissive);

   // distance fog toward the sky-horizon color
   float dist = length(feetPos);
   vec3 dir = feetPos / max(dist, 0.001);
   vec3 fogCol = vw_fogColor(dir, sunDirW, rainStrength);
   float fogAmt = 1.0 - exp(-pow(dist / far * 1.6 * FOG_DENSITY * (1.0 + 0.9 * rainStrength), 2.0));

#ifdef NETHER
   fogCol = mix(fogColor, vec3(0.45, 0.10, 0.22), 0.55) * 0.9;
   fogAmt = 1.0 - exp(-pow(dist / far * 3.0 * FOG_DENSITY, 1.5));
#endif

   if (isEyeInWater == 1) {
      fogCol = vec3(0.04, 0.14, 0.24) * (0.3 + 0.7 * skyL);
      fogAmt = 1.0 - exp(-dist * 0.09);
   }

   albedo.rgb = mix(albedo.rgb, fogCol, clamp(fogAmt, 0.0, 1.0));

/* DRAWBUFFERS:0 */
   gl_FragData[0] = albedo;
}
