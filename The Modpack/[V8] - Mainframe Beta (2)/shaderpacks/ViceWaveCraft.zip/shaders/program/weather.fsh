#include "/settings.glsl"

uniform sampler2D gtexture;

varying vec2 texUV;
varying vec2 lightUV;
varying vec4 vColor;

void main() {
   vec4 albedo = texture2D(gtexture, texUV) * vColor;

   // cool violet rain streaks
   albedo.rgb *= mix(vec3(0.35), vec3(0.90), lightUV.t) * vec3(0.85, 0.80, 1.15);
   albedo.a *= 0.5;

/* DRAWBUFFERS:0 */
   gl_FragData[0] = albedo;
}
