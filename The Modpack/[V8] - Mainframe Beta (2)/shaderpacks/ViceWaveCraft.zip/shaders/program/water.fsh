#include "/settings.glsl"
#include "/common/palette.glsl"

uniform sampler2D gtexture;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform float far;
uniform int isEyeInWater;
uniform vec3 cameraPosition;

varying vec2 texUV;
varying vec2 lightUV;
varying vec4 vColor;
varying vec3 feetPos;
varying vec3 worldNormal;
varying vec3 sunDirW;
varying float isWater;

void main() {
   vec4 albedo = texture2D(gtexture, texUV) * vColor;

   float skyL   = lightUV.t;
   float blockL = lightUV.s;
   vec3 ph = vw_phase(sunDirW.y);

   float dist = length(feetPos);
   vec3 dir = feetPos / max(dist, 0.001);

   if (isWater > 0.5) {
      // procedural wave normal on horizontal faces
      vec3 n = worldNormal;
      if (n.y > 0.9) {
         vec3 wp = feetPos + cameraPosition;
         float t = frameTimeCounter * (0.8 + 0.4 * WATER_WAVES);
         float nx = sin(wp.x * 0.8 + t * 1.4) + 0.6 * sin(wp.x * 2.1 - t * 1.1) + 0.4 * sin((wp.x + wp.z) * 1.3 + t * 1.9);
         float nz = sin(wp.z * 0.9 - t * 1.2) + 0.6 * sin(wp.z * 2.3 + t * 1.5) + 0.4 * sin((wp.z - wp.x) * 1.1 + t * 1.6);
         n = normalize(vec3(nx * 0.045 * WATER_WAVES, 1.0, nz * 0.045 * WATER_WAVES));
      }

      // deep teal by day, drifts purple at dusk and night
      vec3 tint = mix(vec3(0.05, 0.20, 0.30), vec3(0.10, 0.05, 0.22), clamp(ph.y * 0.7 + ph.z, 0.0, 1.0));
      vec3 baseCol = tint * (vw_ambientColor(sunDirW.y, rainStrength) * (0.2 + 0.8 * skyL) * 2.0
                             + vw_blocklightColor(blockL));

      float cosT = clamp(dot(-dir, n), 0.0, 1.0);
      float fresnel = 0.08 + 0.92 * pow(1.0 - cosT, 5.0);

      vec3 rdir = reflect(dir, n);
      rdir.y = max(rdir.y, 0.04);
      rdir = normalize(rdir);

      // the money shot: the sunset sky mirrored in the water
      vec3 refl = vw_skyGradient(rdir, sunDirW, rainStrength);

      float sunGlint  = pow(clamp(dot(rdir,  sunDirW), 0.0, 1.0), 180.0) * (ph.x * 1.5 + ph.y * 3.0);
      float moonGlint = pow(clamp(dot(rdir, -sunDirW), 0.0, 1.0), 180.0) * ph.z * 1.2;
      refl += sunGlint * vw_sunlightColor(sunDirW.y, rainStrength) * (1.0 - rainStrength);
      refl += moonGlint * vec3(0.40, 0.45, 0.70) * (1.0 - rainStrength);

      float skyGate = smoothstep(0.4, 0.9, skyL);
      float reflMix = clamp(fresnel * REFLECTION_STRENGTH, 0.0, 1.0) * skyGate;
      if (isEyeInWater == 1) reflMix *= 0.15;

      albedo.rgb = mix(baseCol, refl, reflMix);
      albedo.a = clamp(WATER_OPACITY + fresnel * 0.35 + sunGlint * 0.3, 0.0, 0.97);
   } else {
      // glass and other translucents: simple lit path
      vec3 light = vw_ambientColor(sunDirW.y, rainStrength) * (0.2 + 0.8 * skyL * skyL)
                 + vw_blocklightColor(blockL)
                 + vw_sunlightColor(sunDirW.y, rainStrength) * (0.6 * pow(skyL, 3.0))
                 + vec3(0.03);
      albedo.rgb *= light;
   }

   vec3 fogCol = vw_fogColor(dir, sunDirW, rainStrength);
   float fogAmt = 1.0 - exp(-pow(dist / far * 1.6 * FOG_DENSITY * (1.0 + 0.9 * rainStrength), 2.0));
   if (isEyeInWater == 1) {
      fogCol = vec3(0.04, 0.14, 0.24) * (0.3 + 0.7 * skyL);
      fogAmt = 1.0 - exp(-dist * 0.09);
   }
   albedo.rgb = mix(albedo.rgb, fogCol, clamp(fogAmt, 0.0, 1.0));

/* DRAWBUFFERS:0 */
   gl_FragData[0] = albedo;
}
