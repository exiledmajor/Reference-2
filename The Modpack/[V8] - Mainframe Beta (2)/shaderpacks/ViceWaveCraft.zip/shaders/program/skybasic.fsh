#include "/settings.glsl"
#include "/common/palette.glsl"

uniform mat4 gbufferModelViewInverse;
uniform float rainStrength;
uniform float frameTimeCounter;

varying vec3 viewDirV;
varying vec3 sunDirW;

void main() {
   vec3 dir = normalize(mat3(gbufferModelViewInverse) * viewDirV);

   vec3 sky = vw_skyGradient(dir, sunDirW, rainStrength);

   // darken the void below the horizon
   sky *= mix(1.0, 0.35, smoothstep(0.04, 0.4, -dir.y));

#ifdef STARS
   vec3 ph = vw_phase(sunDirW.y);
   float night = ph.z * (1.0 - rainStrength);
   if (night > 0.01 && dir.y > 0.05) {
      vec2 suv = dir.xz / (dir.y + 0.55) * 48.0;
      vec2 id = floor(suv);
      float h = vw_hash12(id);
      if (h > 1.0 - 0.006 * STAR_DENSITY) {
         vec2 f = fract(suv) - 0.5;
         vec2 off = vec2(vw_hash12(id + 17.0), vw_hash12(id + 43.0)) * 0.6 - 0.3;
         float d = length(f - off);
         float twinkle = 0.55 + 0.45 * sin(frameTimeCounter * 2.5 + h * 80.0);
         sky += smoothstep(0.10, 0.02, d) * twinkle * night * vec3(0.75, 0.70, 1.00);
      }
   }
#endif

/* DRAWBUFFERS:0 */
   gl_FragData[0] = vec4(sky, 1.0);
}
