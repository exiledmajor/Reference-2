#include "/settings.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;

varying vec3 viewDirV;
varying vec3 sunDirW;

void main() {
   gl_Position = ftransform();
   viewDirV = (gl_ModelViewMatrix * gl_Vertex).xyz;
   sunDirW  = normalize(mat3(gbufferModelViewInverse) * sunPosition);
}
