#include "/settings.glsl"
#include "/common/palette.glsl"

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16F;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform int isEyeInWater;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;

varying vec2 uv;

vec3 aces(vec3 x) {
   return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
   vec2 centered = uv - 0.5;

#ifdef CHROMATIC_ABERRATION
   vec2 caOff = centered * 0.0035;
   vec3 color = vec3(
      texture2D(colortex0, uv + caOff).r,
      texture2D(colortex0, uv).g,
      texture2D(colortex0, uv - caOff).b
   );
#else
   vec3 color = texture2D(colortex0, uv).rgb;
#endif

#ifdef BLOOM
   color += texture2D(colortex1, uv).rgb * (0.18 * BLOOM_STRENGTH);
#endif

   if (isEyeInWater == 1) color *= vec3(0.78, 0.92, 1.12);

   color *= EXPOSURE;
   color = aces(color);

   // ---- Vice grade, faded down in plain daylight ----
#if defined NETHER || defined THE_END
   float grade = 0.7 * GRADE_STRENGTH;
#else
   vec3 sunDirW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
   vec3 ph = vw_phase(sunDirW.y);
   float grade = GRADE_STRENGTH * (0.30 * ph.x + 1.0 * ph.y + 0.75 * ph.z);
#endif

   float l = vw_luma(color);
   // purple shadow lift
   color += vec3(0.085, 0.025, 0.16) * (1.0 - smoothstep(0.0, 0.45, l)) * grade;
   // gentle magenta cast
   color *= mix(vec3(1.0), vec3(1.05, 0.97, 1.05), grade);
   // warm-pink highlights
   color = mix(color, color * vec3(1.10, 0.94, 1.03) + vec3(0.03, 0.0, 0.02),
               smoothstep(0.55, 1.0, l) * 0.6 * grade);
   // gentle s-curve for punch (kept time-independent)
   color = mix(color, color * color * (3.0 - 2.0 * color), 0.22 * GRADE_STRENGTH);

   l = vw_luma(color);
   color = mix(vec3(l), color, float(SATURATION));
   color = mix(vec3(0.5), color, float(CONTRAST));

   float vig = 1.0 - VIGNETTE * smoothstep(0.35, 1.0, dot(centered, centered) * 2.4);
   color *= vig;

   gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
