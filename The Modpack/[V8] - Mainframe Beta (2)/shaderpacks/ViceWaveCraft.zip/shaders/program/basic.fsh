#include "/settings.glsl"

varying vec4 vColor;

void main() {
/* DRAWBUFFERS:0 */
   gl_FragData[0] = vColor;
}
