#include "/settings.glsl"

varying vec2 texUV;
varying vec4 vColor;

void main() {
   gl_Position = ftransform();
   texUV  = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
   vColor = gl_Color;
}
