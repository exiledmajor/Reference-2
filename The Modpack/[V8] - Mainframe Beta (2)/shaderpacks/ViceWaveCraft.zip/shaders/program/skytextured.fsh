#include "/settings.glsl"
#include "/common/palette.glsl"

uniform sampler2D gtexture;
uniform float rainStrength;

varying vec2 texUV;
varying vec4 vColor;
varying vec3 sunDirW;

void main() {
   vec4 albedo = texture2D(gtexture, texUV) * vColor;

#ifdef THE_END
   albedo.rgb *= vec3(0.55, 0.42, 0.95) * 0.9;
#else
   // hot sun / violet moon; pushed past 1.0 so the bloom pass catches it
   vec3 ph = vw_phase(sunDirW.y);
   vec3 tint = ph.x * vec3(1.45, 1.25, 1.05)
             + ph.y * vec3(1.90, 0.80, 0.55)
             + ph.z * vec3(0.95, 0.95, 1.35);
   albedo.rgb *= tint * 1.5;
   albedo.rgb *= 1.0 - 0.8 * rainStrength;
#endif

/* DRAWBUFFERS:0 */
   gl_FragData[0] = albedo;
}
