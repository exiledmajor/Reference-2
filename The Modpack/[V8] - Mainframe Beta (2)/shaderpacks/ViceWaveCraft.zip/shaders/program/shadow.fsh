#include "/settings.glsl"

uniform sampler2D gtexture;

varying vec2 texUV;
varying vec4 vColor;

void main() {
   vec4 albedo = texture2D(gtexture, texUV) * vColor;
   if (albedo.a < 0.1) discard;

   gl_FragData[0] = albedo;
}
