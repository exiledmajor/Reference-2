#ifndef SETTINGS_GLSL
#define SETTINGS_GLSL

// ============================ ViceWave options ============================

// --- Sky ---
#define SUNSET_INTENSITY 1.0 //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0]
#define SKY_BRIGHTNESS 1.0 //[0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5]
#define NIGHT_BRIGHTNESS 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
#define FOG_DENSITY 1.0 //[0.4 0.6 0.8 1.0 1.3 1.6 2.0]
#define STARS
#define STAR_DENSITY 1.0 //[0.5 1.0 1.5 2.0 3.0]

// --- Shadows ---
#define ENABLE_SHADOWS
#define SHADOW_SOFTNESS 1.0 //[0.0 0.5 1.0 1.5 2.0 3.0]
const int   shadowMapResolution = 2048;  //[1024 2048 4096]
const float shadowDistance      = 160.0; //[96.0 128.0 160.0 192.0 256.0]
const float sunPathRotation     = -30.0; //[-60.0 -45.0 -30.0 -15.0 0.0 15.0 30.0 45.0 60.0]
const float shadowIntervalSize  = 8.0;
const float shadowDistanceRenderMul = 1.0;
const float entityShadowDistanceMul = 0.25;

// --- Lighting ---
#define NEON_BLOCKLIGHT 0.6 //[0.0 0.15 0.3 0.45 0.6 0.75 0.9 1.0]
#define NEON_COLOR 0 //[0 1 2 3 4 5 6]
#define BLOCKLIGHT_BRIGHTNESS 1.0 //[0.6 0.8 1.0 1.2 1.4 1.6]
#define EMISSIVE_BOOST 1.2 //[1.0 1.2 1.4 1.8 2.2 2.6 3.0]

// neon tint of the projected blocklight (picked by NEON_COLOR)
#if NEON_COLOR == 0
   #define VW_NEON_TINT vec3(1.00, 0.30, 0.85) // rose magenta
#elif NEON_COLOR == 1
   #define VW_NEON_TINT vec3(0.70, 0.35, 1.00) // violet
#elif NEON_COLOR == 2
   #define VW_NEON_TINT vec3(0.35, 0.55, 1.00) // bleu
#elif NEON_COLOR == 3
   #define VW_NEON_TINT vec3(0.30, 0.95, 1.00) // cyan
#elif NEON_COLOR == 4
   #define VW_NEON_TINT vec3(0.35, 1.00, 0.60) // vert
#elif NEON_COLOR == 5
   #define VW_NEON_TINT vec3(1.00, 0.55, 0.25) // orange
#else
   #define VW_NEON_TINT vec3(1.00, 0.30, 0.30) // rouge
#endif

// --- World motion ---
#define WAVING
#define WAVING_SPEED 1.0 //[0.5 0.75 1.0 1.5 2.0]

// --- Water ---
#define WATER_OPACITY 0.75 //[0.4 0.5 0.6 0.75 0.85 0.95]
#define WATER_WAVES 0.5 //[0.0 0.5 1.0 1.5 2.0]
#define REFLECTION_STRENGTH 1.0 //[0.0 0.25 0.5 0.75 1.0 1.25 1.5]

// --- Post-process ---
#define BLOOM
#define BLOOM_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define EXPOSURE 1.0 //[0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.5]
#define SATURATION 1.15 //[0.8 0.9 1.0 1.05 1.1 1.15 1.2 1.3 1.4]
#define CONTRAST 1.0 //[0.85 0.9 0.95 1.0 1.05 1.1 1.15]
#define GRADE_STRENGTH 1.0 //[0.0 0.25 0.5 0.75 1.0 1.25 1.5]
#define VIGNETTE 0.25 //[0.0 0.15 0.25 0.4 0.6]
//#define CHROMATIC_ABERRATION

// ==========================================================================

#if defined ENABLE_SHADOWS && defined OVERWORLD
   #define SHADOWS_ACTIVE
#endif

#define PI 3.14159265
#define TAU 6.2831853

float vw_luma(vec3 c) {
   return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// pushes shadow map resolution toward the camera
vec2 vw_distortShadow(vec2 p) {
   return p / (0.85 * length(p) + 0.15);
}

float vw_hash12(vec2 p) {
   vec3 p3 = fract(vec3(p.xyx) * 0.1031);
   p3 += dot(p3, p3.yzx + 33.33);
   return fract((p3.x + p3.y) * p3.z);
}

#endif
