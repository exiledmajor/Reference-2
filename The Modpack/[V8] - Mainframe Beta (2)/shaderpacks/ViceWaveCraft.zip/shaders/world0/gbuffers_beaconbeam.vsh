#version 120
#define OVERWORLD
#define BEACON
#include "/program/spidereyes.vsh"
