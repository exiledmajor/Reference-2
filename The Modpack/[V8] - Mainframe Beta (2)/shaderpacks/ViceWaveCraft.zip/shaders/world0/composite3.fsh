#version 120
#define OVERWORLD
#define DIR_V
#define STRIDE 5.0
#include "/program/bloom.fsh"
