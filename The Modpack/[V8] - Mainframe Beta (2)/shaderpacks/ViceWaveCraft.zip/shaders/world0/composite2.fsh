#version 120
#define OVERWORLD
#define DIR_H
#define STRIDE 5.0
#include "/program/bloom.fsh"
