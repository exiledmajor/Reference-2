#version 120
#define OVERWORLD
#define PASS_EXTRACT
#define DIR_H
#define STRIDE 2.0
#include "/program/bloom.fsh"
