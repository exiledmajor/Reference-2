#version 120
#define NETHER
#define PASS_EXTRACT
#define DIR_H
#define STRIDE 2.0
#include "/program/bloom.fsh"
