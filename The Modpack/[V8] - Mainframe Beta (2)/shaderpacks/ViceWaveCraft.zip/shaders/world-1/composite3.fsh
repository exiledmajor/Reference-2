#version 120
#define NETHER
#define DIR_V
#define STRIDE 5.0
#include "/program/bloom.fsh"
