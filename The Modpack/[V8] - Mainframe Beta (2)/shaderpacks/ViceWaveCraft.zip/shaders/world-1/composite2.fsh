#version 120
#define NETHER
#define DIR_H
#define STRIDE 5.0
#include "/program/bloom.fsh"
