#version 120
#define NETHER
#define FACE_SHADE
#include "/program/solid.fsh"
