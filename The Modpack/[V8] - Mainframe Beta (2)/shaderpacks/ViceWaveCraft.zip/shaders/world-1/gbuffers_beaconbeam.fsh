#version 120
#define NETHER
#define BEACON
#include "/program/spidereyes.fsh"
