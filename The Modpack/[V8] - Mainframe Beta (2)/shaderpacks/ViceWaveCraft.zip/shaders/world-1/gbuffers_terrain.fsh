#version 120
#define NETHER
#define TERRAIN
#define FACE_SHADE
#include "/program/solid.fsh"
