#ifndef PALETTE_GLSL
#define PALETTE_GLSL

// requires /settings.glsl to be included first

// phase weights from world-space sun height: x = day, y = dusk/dawn, z = night
vec3 vw_phase(float sunH) {
   float day   = smoothstep(0.10, 0.35, sunH);
   float night = smoothstep(0.08, 0.30, -sunH);
   float dusk  = clamp(1.0 - day - night, 0.0, 1.0);
   return vec3(day, dusk, night);
}

vec3 vw_skyGradient(vec3 dir, vec3 sunDir, float rain) {
#if defined NETHER
   return vec3(0.30, 0.07, 0.14);
#elif defined THE_END
   return vec3(0.055, 0.03, 0.10) + vec3(0.08, 0.04, 0.14) * pow(1.0 - abs(dir.y), 2.0);
#else
   vec3 ph = vw_phase(sunDir.y);

   vec3 zen = ph.x * vec3(0.11, 0.32, 0.86)
            + ph.y * vec3(0.26, 0.14, 0.52)
            + ph.z * vec3(0.015, 0.014, 0.055) * NIGHT_BRIGHTNESS;
   vec3 hor = ph.x * vec3(0.62, 0.78, 0.98)
            + ph.y * vec3(1.00, 0.42, 0.46)
            + ph.z * vec3(0.10, 0.07, 0.21) * NIGHT_BRIGHTNESS;

   float h = pow(1.0 - clamp(dir.y, 0.0, 1.0), 2.5);
   vec3 sky = mix(zen, hor, h);

   // pink band hugging the horizon, strongest on the sun side
   float band = pow(1.0 - abs(dir.y), 4.0);
   float sunSide = 0.5 + 0.5 * dot(normalize(dir.xz + vec2(1e-4)), normalize(sunDir.xz + vec2(1e-4)));
   sky += SUNSET_INTENSITY * ph.y * band * (0.35 + 0.65 * sunSide) * vec3(0.85, 0.25, 0.55);

   // orange glow around the sun at dusk, faint warm halo at day
   float sunDot = max(dot(dir, sunDir), 0.0);
   sky += ph.y * SUNSET_INTENSITY * (pow(sunDot, 6.0) * vec3(1.05, 0.45, 0.15)
                                   + pow(sunDot, 24.0) * vec3(1.20, 0.55, 0.20));
   sky += ph.x * pow(sunDot, 8.0) * vec3(0.20, 0.16, 0.10);

   // violet moon glow
   float moonDot = max(dot(dir, -sunDir), 0.0);
   sky += ph.z * pow(moonDot, 12.0) * vec3(0.10, 0.09, 0.22) * NIGHT_BRIGHTNESS;

   sky *= SKY_BRIGHTNESS;

   // rain flattens everything to a lavender grey
   float g = vw_luma(sky);
   sky = mix(sky, vec3(g) * vec3(0.75, 0.72, 0.88), 0.75 * rain);
   return sky;
#endif
}

// fog takes the near-horizon sky color so distance haze melts into the sky
vec3 vw_fogColor(vec3 dir, vec3 sunDir, float rain) {
   vec3 d = normalize(vec3(dir.x, max(dir.y, 0.0) * 0.25 + 0.04, dir.z));
   return vw_skyGradient(d, sunDir, rain);
}

vec3 vw_sunlightColor(float sunH, float rain) {
   vec3 ph = vw_phase(sunH);
   vec3 c = ph.x * vec3(0.92, 0.86, 0.76)
          + ph.y * vec3(1.25, 0.45, 0.30)
          + ph.z * vec3(0.16, 0.16, 0.30) * NIGHT_BRIGHTNESS;
   return c * (1.0 - 0.85 * rain);
}

vec3 vw_ambientColor(float sunH, float rain) {
#if defined NETHER
   return vec3(0.45, 0.28, 0.36);
#elif defined THE_END
   return vec3(0.34, 0.28, 0.44);
#else
   vec3 ph = vw_phase(sunH);
   vec3 c = ph.x * vec3(0.40, 0.46, 0.60)
          + ph.y * vec3(0.52, 0.34, 0.55)
          + ph.z * vec3(0.14, 0.13, 0.26) * NIGHT_BRIGHTNESS;
   return mix(c, vec3(vw_luma(c)) * vec3(0.90, 0.90, 1.05), 0.4 * rain);
#endif
}

vec3 vw_blocklightColor(float blockL) {
   // warm sodium base blended toward the chosen neon color
   vec3 warm = vec3(1.00, 0.58, 0.32);
   vec3 tint = mix(warm, VW_NEON_TINT, float(NEON_BLOCKLIGHT));
   float b = blockL * blockL;
   return tint * b * (1.8 * BLOCKLIGHT_BRIGHTNESS);
}

#endif
