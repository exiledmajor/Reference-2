#version 120
#define THE_END
#define DIR_V
#define STRIDE 2.0
#include "/program/bloom.fsh"
