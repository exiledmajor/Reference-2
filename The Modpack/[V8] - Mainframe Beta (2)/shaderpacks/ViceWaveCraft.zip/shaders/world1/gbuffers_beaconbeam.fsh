#version 120
#define THE_END
#define BEACON
#include "/program/spidereyes.fsh"
