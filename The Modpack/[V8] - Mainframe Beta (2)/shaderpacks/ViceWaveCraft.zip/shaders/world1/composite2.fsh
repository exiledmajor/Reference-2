#version 120
#define THE_END
#define DIR_H
#define STRIDE 5.0
#include "/program/bloom.fsh"
