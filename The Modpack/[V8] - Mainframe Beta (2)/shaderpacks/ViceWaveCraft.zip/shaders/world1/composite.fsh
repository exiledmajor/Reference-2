#version 120
#define THE_END
#define PASS_EXTRACT
#define DIR_H
#define STRIDE 2.0
#include "/program/bloom.fsh"
