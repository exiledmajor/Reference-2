#version 120
#define THE_END
#include "/program/solid.vsh"
